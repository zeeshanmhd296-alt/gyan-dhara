# Gyan Dhara — AAB Builder (No Android Studio)

Package: com.gyandhara.app
Version: 1.0.0
Target SDK: 35

This build is intentionally limited to the first launch scope: a 10-question quiz session selected from a bundled 10,000-question bank.

Build using GitHub Actions; see BUILD_WITH_GITHUB.md.
