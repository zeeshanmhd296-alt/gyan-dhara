package com.gyandhara.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import kotlin.random.Random

data class Question(
    val question: String,
    val options: List<String>,
    val answer: String,
    val explanation: String,
    val category: String
)

class MainActivity : Activity() {
    private lateinit var bank: List<Question>
    private var index = 0
    private var score = 0
    private var selected: String? = null
    private lateinit var questionText: TextView
    private lateinit var optionsBox: LinearLayout
    private lateinit var progress: TextView
    private lateinit var scoreView: TextView
    private lateinit var nextButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bank = loadQuestions().shuffled()
        showHome()
    }

    private fun loadQuestions(): List<Question> {
        val text = assets.open("questions.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val opts = listOf("optionA","optionB","optionC","optionD").map { o.getString(it) }
            Question(o.getString("question"), opts, o.getString("correctAnswer"),
                o.optString("explanation",""), o.optString("category","General"))
        }
    }

    private fun base(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
            setBackgroundColor(Color.WHITE)
        }
        return root
    }

    private fun showHome() {
        val root=base()
        val title=TextView(this).apply { text="Gyan Dhara"; textSize=34f; setTextColor(Color.rgb(20,55,100)); gravity=Gravity.CENTER; setPadding(0,60,0,10) }
        val sub=TextView(this).apply { text="Learn anything. Test yourself."; textSize=18f; gravity=Gravity.CENTER; setPadding(0,0,0,30) }
        val info=TextView(this).apply { text="10,000-question launch edition"; textSize=16f; gravity=Gravity.CENTER; setPadding(0,10,0,30) }
        val start=Button(this).apply { text="START QUIZ"; textSize=18f; setOnClickListener { index=0; score=0; bank=bank.shuffled(); showQuestion() } }
        root.addView(title, LinearLayout.LayoutParams(-1, -2)); root.addView(sub, LinearLayout.LayoutParams(-1,-2))
        root.addView(info, LinearLayout.LayoutParams(-1,-2)); root.addView(start, LinearLayout.LayoutParams(-1,60))
        setContentView(root)
    }

    private fun showQuestion() {
        if(index>=minOf(10,bank.size)){ showResult(); return }
        selected=null
        val q=bank[index]
        val root=base()
        progress=TextView(this).apply { text="Question ${index+1}/10   •   ${q.category}"; textSize=15f; setPadding(0,5,0,18) }
        scoreView=TextView(this).apply { text="Score: $score"; textSize=16f; setPadding(0,0,0,18) }
        questionText=TextView(this).apply { text=q.question; textSize=23f; setTextColor(Color.rgb(25,35,50)); setPadding(0,0,0,24) }
        optionsBox=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        q.options.forEach { option ->
            val b=Button(this).apply { text=option; textSize=16f; setOnClickListener { choose(option,q) } }
            optionsBox.addView(b, LinearLayout.LayoutParams(-1,58).apply{setMargins(0,0,0,10)})
        }
        nextButton=Button(this).apply { text="NEXT"; isEnabled=false; setOnClickListener { index++; showQuestion() } }
        root.addView(progress); root.addView(scoreView); root.addView(questionText); root.addView(optionsBox, LinearLayout.LayoutParams(-1,0,1f)); root.addView(nextButton)
        setContentView(root)
    }

    private fun choose(option:String,q:Question){
        if(selected!=null) return
        selected=option
        if(option==q.answer) score+=10
        Toast.makeText(this, if(option==q.answer) "Correct! +10" else "Correct answer: ${q.answer}", Toast.LENGTH_SHORT).show()
        scoreView.text="Score: $score"
        nextButton.isEnabled=true
    }

    private fun showResult(){
        val root=base()
        val t=TextView(this).apply{text="Quiz complete!";textSize=30f;gravity=Gravity.CENTER;setPadding(0,70,0,20)}
        val s=TextView(this).apply{text="Your score: $score / 100";textSize=22f;gravity=Gravity.CENTER;setPadding(0,10,0,30)}
        val again=Button(this).apply{text="PLAY AGAIN";setOnClickListener{index=0;score=0;bank=bank.shuffled();showQuestion()}}
        root.addView(t,LinearLayout.LayoutParams(-1,-2));root.addView(s,LinearLayout.LayoutParams(-1,-2));root.addView(again,LinearLayout.LayoutParams(-1,60))
        setContentView(root)
    }
}
