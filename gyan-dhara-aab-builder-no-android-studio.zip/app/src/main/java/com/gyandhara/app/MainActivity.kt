package com.gyandhara.app

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONArray

data class Question(
    val factId: Int,
    val question: String,
    val options: List<String>,
    val answer: String,
    val category: String,
    val questionHi: String? = null,
    val optionsHi: List<String>? = null,
    val answerHi: String? = null,
    val categoryHi: String? = null
)

object Strings {
    val en = mapOf(
        "app_title" to "Gyan Dhara",
        "welcome" to "Welcome to",
        "tagline" to "Learn anything. Test yourself.",
        "next" to "NEXT",
        "play_again" to "PLAY AGAIN",
        "exam_complete" to "Exam complete!",
        "score_label" to "Score",
        "your_score" to "Your score",
        "question_label" to "Question",
        "correct_answer_prefix" to "Correct answer:",
        "lang_toggle" to "हिंदी",
        "nav_home" to "Home",
        "nav_history" to "History",
        "nav_science" to "Science",
        "nav_exam" to "Exam",
        "cat_history" to "History",
        "cat_science" to "Science",
        "cat_general" to "General Knowledge",
        "cat_exam" to "Practice Exam",
        "quick_access" to "Quick Access"
    )
    val hi = mapOf(
        "app_title" to "ज्ञान धारा",
        "welcome" to "आपका स्वागत है",
        "tagline" to "कुछ भी सीखें। खुद को परखें।",
        "next" to "अगला",
        "play_again" to "फिर से खेलें",
        "exam_complete" to "परीक्षा पूरी हुई!",
        "score_label" to "स्कोर",
        "your_score" to "आपका स्कोर",
        "question_label" to "प्रश्न",
        "correct_answer_prefix" to "सही उत्तर:",
        "lang_toggle" to "English",
        "nav_home" to "होम",
        "nav_history" to "इतिहास",
        "nav_science" to "विज्ञान",
        "nav_exam" to "परीक्षा",
        "cat_history" to "इतिहास",
        "cat_science" to "विज्ञान",
        "cat_general" to "सामान्य ज्ञान",
        "cat_exam" to "अभ्यास परीक्षा",
        "quick_access" to "त्वरित पहुँच"
    )
}

data class TopicFact(val qEn: String, val qHi: String, val ansEn: String, val ansHi: String)
data class TopicQuizQ(val qEn: String, val qHi: String, val optsEn: List<String>, val optsHi: List<String>, val ansEn: String, val ansHi: String)
data class GkTopic(val id: String, val titleEn: String, val titleHi: String, val introEn: String, val introHi: String)

object GkData {
    // English name, Hindi name, English capital, Hindi capital
    val states = listOf(
        listOf("Andhra Pradesh","आंध्र प्रदेश","Amaravati","अमरावती"),
        listOf("Arunachal Pradesh","अरुणाचल प्रदेश","Itanagar","ईटानगर"),
        listOf("Assam","असम","Dispur","दिसपुर"),
        listOf("Bihar","बिहार","Patna","पटना"),
        listOf("Chhattisgarh","छत्तीसगढ़","Raipur","रायपुर"),
        listOf("Goa","गोवा","Panaji","पणजी"),
        listOf("Gujarat","गुजरात","Gandhinagar","गांधीनगर"),
        listOf("Haryana","हरियाणा","Chandigarh","चंडीगढ़"),
        listOf("Himachal Pradesh","हिमाचल प्रदेश","Shimla","शिमला"),
        listOf("Jharkhand","झारखंड","Ranchi","रांची"),
        listOf("Karnataka","कर्नाटक","Bengaluru","बेंगलुरु"),
        listOf("Kerala","केरल","Thiruvananthapuram","तिरुवनंतपुरम"),
        listOf("Madhya Pradesh","मध्य प्रदेश","Bhopal","भोपाल"),
        listOf("Maharashtra","महाराष्ट्र","Mumbai","मुंबई"),
        listOf("Manipur","मणिपुर","Imphal","इम्फाल"),
        listOf("Meghalaya","मेघालय","Shillong","शिलांग"),
        listOf("Mizoram","मिज़ोरम","Aizawl","आइज़ोल"),
        listOf("Nagaland","नगालैंड","Kohima","कोहिमा"),
        listOf("Odisha","ओडिशा","Bhubaneswar","भुवनेश्वर"),
        listOf("Punjab","पंजाब","Chandigarh","चंडीगढ़"),
        listOf("Rajasthan","राजस्थान","Jaipur","जयपुर"),
        listOf("Sikkim","सिक्किम","Gangtok","गंगटोक"),
        listOf("Tamil Nadu","तमिलनाडु","Chennai","चेन्नई"),
        listOf("Telangana","तेलंगाना","Hyderabad","हैदराबाद"),
        listOf("Tripura","त्रिपुरा","Agartala","अगरतला"),
        listOf("Uttar Pradesh","उत्तर प्रदेश","Lucknow","लखनऊ"),
        listOf("Uttarakhand","उत्तराखंड","Dehradun","देहरादून"),
        listOf("West Bengal","पश्चिम बंगाल","Kolkata","कोलकाता")
    )

    val historyFacts = listOf(
        TopicFact("When did India get independence?","भारत को स्वतंत्रता कब मिली?","15 August 1947","15 अगस्त 1947"),
        TopicFact("Who was India's first Prime Minister?","भारत के पहले प्रधानमंत्री कौन थे?","Jawaharlal Nehru","जवाहरलाल नेहरू"),
        TopicFact("Who was India's first President?","भारत के पहले राष्ट्रपति कौन थे?","Dr. Rajendra Prasad","डॉ. राजेंद्र प्रसाद"),
        TopicFact("When was the Indian National Congress founded?","भारतीय राष्ट्रीय कांग्रेस की स्थापना कब हुई?","1885","1885"),
        TopicFact("Who founded the Maurya Empire?","मौर्य साम्राज्य की स्थापना किसने की?","Chandragupta Maurya","चंद्रगुप्त मौर्य"),
        TopicFact("When did the Quit India Movement begin?","भारत छोड़ो आंदोलन कब शुरू हुआ?","1942","1942"),
        TopicFact("Who started the Non-Cooperation Movement?","असहयोग आंदोलन किसने शुरू किया?","Mahatma Gandhi","महात्मा गांधी"),
        TopicFact("When did the Dandi March (Salt Satyagraha) take place?","दांडी मार्च (नमक सत्याग्रह) कब हुआ?","1930","1930"),
        TopicFact("In which year was India partitioned?","भारत का विभाजन किस वर्ष हुआ?","1947","1947"),
        TopicFact("Which dynasty did Ashoka belong to?","अशोक किस वंश के सम्राट थे?","Maurya dynasty","मौर्य वंश"),
        TopicFact("Who built the Taj Mahal?","ताजमहल का निर्माण किसने करवाया?","Shah Jahan","शाहजहाँ"),
        TopicFact("Where did the Revolt of 1857 begin?","सिपाही विद्रोह (1857) की शुरुआत कहाँ से हुई?","Meerut","मेरठ"),
        TopicFact("When did the Indian Constitution come into effect?","भारतीय संविधान कब लागू हुआ?","26 January 1950","26 जनवरी 1950"),
        TopicFact("Who is known as the 'Iron Man of India'?","भारत के लौह पुरुष किसे कहा जाता है?","Sardar Vallabhbhai Patel","सरदार वल्लभभाई पटेल")
    )

    val historyQuiz = listOf(
        TopicQuizQ("When did India get independence?","भारत को स्वतंत्रता कब मिली?",
            listOf("15 August 1947","26 January 1950","2 October 1947","15 August 1950"),
            listOf("15 अगस्त 1947","26 जनवरी 1950","2 अक्टूबर 1947","15 अगस्त 1950"),
            "15 August 1947","15 अगस्त 1947"),
        TopicQuizQ("Who was India's first Prime Minister?","भारत के पहले प्रधानमंत्री कौन थे?",
            listOf("Jawaharlal Nehru","Sardar Patel","Mahatma Gandhi","Dr. Rajendra Prasad"),
            listOf("जवाहरलाल नेहरू","सरदार पटेल","महात्मा गांधी","डॉ. राजेंद्र प्रसाद"),
            "Jawaharlal Nehru","जवाहरलाल नेहरू"),
        TopicQuizQ("Who was India's first President?","भारत के पहले राष्ट्रपति कौन थे?",
            listOf("Jawaharlal Nehru","S. Radhakrishnan","Dr. Rajendra Prasad","Zakir Husain"),
            listOf("जवाहरलाल नेहरू","एस. राधाकृष्णन","डॉ. राजेंद्र प्रसाद","ज़ाकिर हुसैन"),
            "Dr. Rajendra Prasad","डॉ. राजेंद्र प्रसाद"),
        TopicQuizQ("When was the Indian National Congress founded?","भारतीय राष्ट्रीय कांग्रेस की स्थापना कब हुई?",
            listOf("1885","1905","1857","1947"),
            listOf("1885","1905","1857","1947"),
            "1885","1885"),
        TopicQuizQ("Who founded the Maurya Empire?","मौर्य साम्राज्य की स्थापना किसने की?",
            listOf("Chandragupta Maurya","Ashoka","Bindusara","Harsha"),
            listOf("चंद्रगुप्त मौर्य","अशोक","बिंदुसार","हर्ष"),
            "Chandragupta Maurya","चंद्रगुप्त मौर्य"),
        TopicQuizQ("When did the Quit India Movement begin?","भारत छोड़ो आंदोलन कब शुरू हुआ?",
            listOf("1942","1930","1920","1947"),
            listOf("1942","1930","1920","1947"),
            "1942","1942"),
        TopicQuizQ("Who started the Non-Cooperation Movement?","असहयोग आंदोलन किसने शुरू किया?",
            listOf("Mahatma Gandhi","Subhas Chandra Bose","Bal Gangadhar Tilak","Jawaharlal Nehru"),
            listOf("महात्मा गांधी","सुभाष चंद्र बोस","बाल गंगाधर तिलक","जवाहरलाल नेहरू"),
            "Mahatma Gandhi","महात्मा गांधी"),
        TopicQuizQ("When did the Dandi March take place?","दांडी मार्च कब हुआ?",
            listOf("1930","1942","1920","1919"),
            listOf("1930","1942","1920","1919"),
            "1930","1930"),
        TopicQuizQ("In which year was India partitioned?","भारत का विभाजन किस वर्ष हुआ?",
            listOf("1947","1950","1942","1930"),
            listOf("1947","1950","1942","1930"),
            "1947","1947"),
        TopicQuizQ("Which dynasty did Ashoka belong to?","अशोक किस वंश के सम्राट थे?",
            listOf("Maurya dynasty","Gupta dynasty","Kushan dynasty","Chola dynasty"),
            listOf("मौर्य वंश","गुप्त वंश","कुषाण वंश","चोल वंश"),
            "Maurya dynasty","मौर्य वंश"),
        TopicQuizQ("Who built the Taj Mahal?","ताजमहल किसने बनवाया?",
            listOf("Shah Jahan","Akbar","Aurangzeb","Humayun"),
            listOf("शाहजहाँ","अकबर","औरंगज़ेब","हुमायूँ"),
            "Shah Jahan","शाहजहाँ"),
        TopicQuizQ("Where did the Revolt of 1857 begin?","सिपाही विद्रोह 1857 कहाँ से शुरू हुआ?",
            listOf("Meerut","Delhi","Lucknow","Kanpur"),
            listOf("मेरठ","दिल्ली","लखनऊ","कानपुर"),
            "Meerut","मेरठ"),
        TopicQuizQ("When did the Indian Constitution come into effect?","भारतीय संविधान कब लागू हुआ?",
            listOf("26 January 1950","15 August 1947","26 November 1949","2 October 1950"),
            listOf("26 जनवरी 1950","15 अगस्त 1947","26 नवंबर 1949","2 अक्टूबर 1950"),
            "26 January 1950","26 जनवरी 1950"),
        TopicQuizQ("Who is known as the 'Iron Man of India'?","भारत के लौह पुरुष किसे कहा जाता है?",
            listOf("Sardar Vallabhbhai Patel","B. R. Ambedkar","Subhas Chandra Bose","Bhagat Singh"),
            listOf("सरदार वल्लभभाई पटेल","बी.आर. अंबेडकर","सुभाष चंद्र बोस","भगत सिंह"),
            "Sardar Vallabhbhai Patel","सरदार वल्लभभाई पटेल")
    )
}

class MainActivity : Activity() {
    private lateinit var bank: List<Question>
    private var lang = "en"

    private var currentCatKey = "ALL"
    private var currentCatFilter: String? = null

    private var isExam = false
    private var examFacts: List<Int> = emptyList()
    private var examIndex = 0
    private var examScore = 0

    private val COLOR_BLUE = Color.rgb(30, 64, 175)
    private val COLOR_RED = Color.rgb(220, 38, 38)
    private val COLOR_DEFAULT = Color.rgb(238, 238, 240)
    private val COLOR_HEADER = Color.rgb(13, 71, 161)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bank = loadQuestions()
        val savedKey = prefs().getString("lastCatKey", null)
        if (savedKey != null && getAnswered(savedKey) > 0) {
            currentCatKey = savedKey
            currentCatFilter = if (savedKey == "ALL") null else savedKey
            isExam = false
            showNextContinuous()
        } else {
            showHome()
        }
    }

    private fun prefs(): SharedPreferences = getSharedPreferences("gyan_dhara_prefs", MODE_PRIVATE)
    private fun s(key: String): String {
        val map = if (lang == "hi") Strings.hi else Strings.en
        return map[key] ?: (Strings.en[key] ?: key)
    }

    private fun loadQuestions(): List<Question> {
        val text = assets.open("questions.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val opts = listOf("optionA","optionB","optionC","optionD").map { o.getString(it) }
            val optsHi = if (o.has("optionAHi")) {
                listOf("optionAHi","optionBHi","optionCHi","optionDHi").map { o.optString(it, "") }
            } else null
            Question(
                factId = o.getInt("factId"),
                question = o.getString("question"),
                options = opts,
                answer = o.getString("correctAnswer"),
                category = o.optString("category","General"),
                questionHi = o.optString("questionHi", "").ifBlank { null },
                optionsHi = optsHi,
                answerHi = o.optString("correctAnswerHi", "").ifBlank { null },
                categoryHi = o.optString("categoryHi", "").ifBlank { null }
            )
        }
    }

    private fun qText(q: Question): String = if (lang=="hi" && !q.questionHi.isNullOrBlank()) q.questionHi else q.question
    private fun qOptions(q: Question): List<String> = if (lang=="hi" && q.optionsHi!=null && q.optionsHi.all{it.isNotBlank()}) q.optionsHi else q.options
    private fun qCategory(q: Question): String = if (lang=="hi" && !q.categoryHi.isNullOrBlank()) q.categoryHi else q.category
    private fun correctDisplayed(q: Question): String = if (lang=="hi" && !q.answerHi.isNullOrBlank()) q.answerHi else q.answer

    private fun allFactsFor(cat: String?): List<Int> = bank.filter { cat == null || it.category == cat }.map { it.factId }.distinct()
    private fun pickRowForFact(factId: Int, cat: String?): Question =
        bank.filter { it.factId == factId && (cat == null || it.category == cat) }.random()

    private fun loadRemaining(catKey: String): MutableList<Int> {
        val s = prefs().getString("remaining_$catKey", null)
        return if (s.isNullOrBlank()) mutableListOf() else s.split(",").filter{it.isNotBlank()}.map{it.toInt()}.toMutableList()
    }
    private fun saveRemaining(catKey: String, list: List<Int>) { prefs().edit().putString("remaining_$catKey", list.joinToString(",")).apply() }
    private fun nextFact(catKey: String, cat: String?): Int {
        var remaining = loadRemaining(catKey)
        if (remaining.isEmpty()) {
            var fresh = allFactsFor(cat).shuffled()
            val last = prefs().getInt("lastFact_$catKey", -1)
            if (fresh.size > 1 && fresh.first() == last) {
                fresh = fresh.toMutableList().apply { val t=this[0]; this[0]=this[1]; this[1]=t }
            }
            remaining = fresh.toMutableList()
        }
        val fact = remaining.removeAt(0)
        saveRemaining(catKey, remaining)
        prefs().edit().putInt("lastFact_$catKey", fact).apply()
        return fact
    }
    private fun getScore(catKey: String) = prefs().getInt("score_$catKey", 0)
    private fun setScore(catKey: String, v: Int) { prefs().edit().putInt("score_$catKey", v).apply() }
    private fun getAnswered(catKey: String) = prefs().getInt("answered_$catKey", 0)
    private fun setAnswered(catKey: String, v: Int) { prefs().edit().putInt("answered_$catKey", v).apply() }

    private fun roundedBg(color: Int, radius: Float = 28f): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }

    // ---- Screen scaffold: content area + persistent bottom nav ----
    private fun renderScreen(activeTab: String, contentBuilder: (LinearLayout) -> Unit) {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }

        val contentArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,20,28,20) }
        contentBuilder(contentArea)
        val scroll = ScrollView(this).apply { addView(contentArea, LinearLayout.LayoutParams(-1,-2)) }

        val bottomNav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(245,247,250))
        }
        fun navItem(label: String, tabKey: String, onClick: () -> Unit): TextView = TextView(this).apply {
            text = label; gravity = Gravity.CENTER; textSize = 13f; setPadding(0,20,0,20)
            setTextColor(if (tabKey == activeTab) COLOR_HEADER else Color.rgb(120,120,130))
            setOnClickListener { onClick() }
        }
        bottomNav.addView(navItem(s("nav_home"), "home") { showHome() }, LinearLayout.LayoutParams(0,-2,1f))
        bottomNav.addView(navItem(s("nav_history"), "history") { startCategory("History") }, LinearLayout.LayoutParams(0,-2,1f))
        bottomNav.addView(navItem(s("nav_science"), "science") { startCategory("Science") }, LinearLayout.LayoutParams(0,-2,1f))
        bottomNav.addView(navItem(s("nav_exam"), "exam") { startExam() }, LinearLayout.LayoutParams(0,-2,1f))

        outer.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        outer.addView(bottomNav, LinearLayout.LayoutParams(-1,-2))

        ViewCompat.setOnApplyWindowInsetsListener(outer) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            contentArea.setPadding(28 + bars.left, 20 + bars.top, 28 + bars.right, 20)
            bottomNav.setPadding(bars.left, 10, bars.right, 10 + bars.bottom)
            insets
        }
        setContentView(outer)
    }

    private fun showHome() {
        renderScreen("home") { content ->
            val langToggle = Button(this).apply {
                text = s("lang_toggle"); textSize = 13f; setPadding(18,8,18,8)
                setOnClickListener { lang = if (lang=="hi") "en" else "hi"; showHome() }
            }
            val toggleRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.END }
            toggleRow.addView(langToggle, LinearLayout.LayoutParams(-2,-2))

            val header = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBg(COLOR_HEADER, 32f)
                setPadding(36,36,36,36)
            }
            val welcome = TextView(this).apply { text=s("welcome"); textSize=16f; setTextColor(Color.rgb(200,220,255)) }
            val title = TextView(this).apply { text=s("app_title"); textSize=30f; setTextColor(Color.WHITE); setPadding(0,6,0,10) }
            val tagline = TextView(this).apply { text=s("tagline"); textSize=15f; setTextColor(Color.rgb(220,230,250)) }
            header.addView(welcome); header.addView(title); header.addView(tagline)

            val sectionLabel = TextView(this).apply { text=s("quick_access"); textSize=20f; setTextColor(Color.rgb(20,30,50)); setPadding(4,36,0,16) }

            fun card(label: String, bg: Int, onClick: () -> Unit): TextView = TextView(this).apply {
                text = label; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.rgb(20,30,50))
                background = roundedBg(bg, 24f); setPadding(20,50,20,50)
                setOnClickListener { onClick() }
            }
            val row1 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            row1.addView(card(s("cat_history"), Color.rgb(212,234,252)) { startCategory("History") }, LinearLayout.LayoutParams(0,-2,1f).apply{ setMargins(0,0,10,10) })
            row1.addView(card(s("cat_science"), Color.rgb(255,244,214)) { startCategory("Science") }, LinearLayout.LayoutParams(0,-2,1f).apply{ setMargins(10,0,0,10) })
            val row2 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            row2.addView(card(s("cat_general"), Color.rgb(230,224,250)) { startCategory(null) }, LinearLayout.LayoutParams(0,-2,1f).apply{ setMargins(0,0,10,0) })
            row2.addView(card(s("cat_exam"), Color.rgb(214,246,224)) { startExam() }, LinearLayout.LayoutParams(0,-2,1f).apply{ setMargins(10,0,0,0) })

            val gkTopicsBtn = TextView(this).apply {
                text = if (lang=="hi") "विषयवार अध्ययन (GK Topics)" else "Topic-wise Study (GK Topics)"
                textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.rgb(20,30,50))
                background = roundedBg(Color.rgb(255,236,214), 24f); setPadding(20,40,20,40)
                setOnClickListener { showGkTopicsList() }
            }

            content.addView(toggleRow, LinearLayout.LayoutParams(-1,-2))
            content.addView(header, LinearLayout.LayoutParams(-1,-2))
            content.addView(sectionLabel, LinearLayout.LayoutParams(-1,-2))
            content.addView(row1, LinearLayout.LayoutParams(-1,-2))
            content.addView(row2, LinearLayout.LayoutParams(-1,-2))
            content.addView(gkTopicsBtn, LinearLayout.LayoutParams(-1,-2).apply{ setMargins(0,20,0,0) })
        }
    }

    // ---- GK Topics: template feature (Topic list -> Detail -> Content or Test) ----
    private val gkTopics = listOf(
        GkTopic("states_capitals",
            "States and Capitals","भारत के राज्य और उनकी राजधानियाँ",
            "India has 28 states, each with its own capital city. Knowing these is essential for every general knowledge exam.",
            "भारत में 28 राज्य हैं, जिनमें से प्रत्येक की अपनी राजधानी है। सभी सामान्य ज्ञान परीक्षाओं के लिए इन्हें जानना ज़रूरी है।"),
        GkTopic("indian_history",
            "Indian History","भारत का इतिहास",
            "India has a rich and long history spanning ancient empires, medieval dynasties, and the freedom struggle against British rule.",
            "भारत का इतिहास प्राचीन साम्राज्यों, मध्यकालीन राजवंशों और ब्रिटिश शासन के विरुद्ध स्वतंत्रता संग्राम तक फैला हुआ है।")
    )

    private fun gkQuizFor(topicId: String): List<TopicQuizQ> = when (topicId) {
        "states_capitals" -> GkData.states.shuffled().take(20).map { st ->
            val wrongCapitals = GkData.states.filter { it[0] != st[0] }.shuffled().take(3)
            val optsEn = (wrongCapitals.map { it[2] } + st[2]).shuffled()
            val optsHi = optsEn.map { capEn -> GkData.states.first { it[2] == capEn }[3] }
            TopicQuizQ(
                "What is the capital of ${st[0]}?", "${st[1]} की राजधानी क्या है?",
                optsEn, optsHi, st[2], st[3]
            )
        }
        "indian_history" -> GkData.historyQuiz
        else -> emptyList()
    }

    private fun gkAttempted(topicId: String) = prefs().getBoolean("gktopic_${topicId}_attempted", false)
    private fun gkLastScore(topicId: String) = prefs().getInt("gktopic_${topicId}_score", 0)

    private fun showGkTopicsList() {
        renderScreen("home") { content ->
            val title = TextView(this).apply { text = if (lang=="hi") "GK विषय" else "GK Topics"; textSize=24f; setTextColor(Color.rgb(20,30,50)); setPadding(0,0,0,20) }
            content.addView(title, LinearLayout.LayoutParams(-1,-2))
            gkTopics.forEach { topic ->
                val attempted = gkAttempted(topic.id)
                val statusText = if (attempted) {
                    (if (lang=="hi") "पूरा हुआ — स्कोर: " else "Completed — Score: ") + "${gkLastScore(topic.id)}/${gkQuizFor(topic.id).size.coerceAtLeast(1)*10}"
                } else (if (lang=="hi") "टेस्ट नहीं दिया है" else "Test not attempted")
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = roundedBg(Color.rgb(224,242,233), 24f)
                    setPadding(30,30,30,30)
                    setOnClickListener { showGkTopicDetail(topic) }
                }
                val t = TextView(this).apply { text = if (lang=="hi") topic.titleHi else topic.titleEn; textSize=19f; setTextColor(Color.rgb(20,60,45)) }
                val st = TextView(this).apply { text = statusText; textSize=14f; setTextColor(Color.rgb(60,100,85)); setPadding(0,10,0,0) }
                card.addView(t); card.addView(st)
                content.addView(card, LinearLayout.LayoutParams(-1,-2).apply{ setMargins(0,0,0,16) })
            }
        }
    }

    private fun showGkTopicDetail(topic: GkTopic) {
        renderScreen("home") { content ->
            val title = TextView(this).apply { text = if (lang=="hi") topic.titleHi else topic.titleEn; textSize=22f; setTextColor(Color.rgb(20,30,50)); setPadding(0,0,0,10) }
            val intro = TextView(this).apply { text = if (lang=="hi") topic.introHi else topic.introEn; textSize=15f; setTextColor(Color.rgb(80,80,90)); setPadding(0,0,0,30) }
            val viewBtn = Button(this).apply { text = if (lang=="hi") "विवरण देखें" else "View Details"; setOnClickListener { showGkTopicContent(topic) } }
            val testBtn = Button(this).apply { text = if (lang=="hi") "ऑनलाइन टेस्ट" else "Online Test"; setOnClickListener { startGkTopicQuiz(topic) } }
            content.addView(title, LinearLayout.LayoutParams(-1,-2))
            content.addView(intro, LinearLayout.LayoutParams(-1,-2))
            content.addView(viewBtn, LinearLayout.LayoutParams(-1,-2).apply{ setMargins(0,0,0,14) })
            content.addView(testBtn, LinearLayout.LayoutParams(-1,-2))
        }
    }

    private fun showGkTopicContent(topic: GkTopic) {
        renderScreen("home") { content ->
            val title = TextView(this).apply { text = if (lang=="hi") topic.titleHi else topic.titleEn; textSize=21f; setTextColor(Color.rgb(20,30,50)); setPadding(0,0,0,16) }
            content.addView(title, LinearLayout.LayoutParams(-1,-2))
            if (topic.id == "states_capitals") {
                GkData.states.forEach { st ->
                    val row = TextView(this).apply {
                        text = if (lang=="hi") "${st[1]}  —  ${st[3]}" else "${st[0]}  —  ${st[2]}"
                        textSize = 16f; setPadding(0,10,0,10); setTextColor(Color.rgb(30,40,55))
                    }
                    content.addView(row, LinearLayout.LayoutParams(-1,-2))
                }
            } else if (topic.id == "indian_history") {
                val intro = TextView(this).apply { text = if (lang=="hi") topic.introHi else topic.introEn; textSize=15f; setTextColor(Color.rgb(80,80,90)); setPadding(0,0,0,24) }
                content.addView(intro, LinearLayout.LayoutParams(-1,-2))
                GkData.historyFacts.forEachIndexed { i, f ->
                    val q = TextView(this).apply { text = "${i+1}. " + (if (lang=="hi") f.qHi else f.qEn); textSize=16f; setTextColor(Color.rgb(20,30,50)); setPadding(0,14,0,4) }
                    val a = TextView(this).apply { text = (if (lang=="hi") "उत्तर: " else "Answer: ") + (if (lang=="hi") f.ansHi else f.ansEn); textSize=15f; setTextColor(Color.rgb(30,110,90)) }
                    content.addView(q, LinearLayout.LayoutParams(-1,-2)); content.addView(a, LinearLayout.LayoutParams(-1,-2))
                }
            }
        }
    }

    private var gkQuizList: List<TopicQuizQ> = emptyList()
    private var gkQuizIndex = 0
    private var gkQuizScore = 0
    private lateinit var gkQuizTopic: GkTopic

    private fun startGkTopicQuiz(topic: GkTopic) {
        gkQuizTopic = topic
        gkQuizList = gkQuizFor(topic.id)
        gkQuizIndex = 0
        gkQuizScore = 0
        showNextGkQuiz()
    }

    private fun showNextGkQuiz() {
        if (gkQuizIndex >= gkQuizList.size) {
            prefs().edit().putBoolean("gktopic_${gkQuizTopic.id}_attempted", true)
                .putInt("gktopic_${gkQuizTopic.id}_score", gkQuizScore).apply()
            renderScreen("home") { content ->
                val t = TextView(this).apply { text = if (lang=="hi") "टेस्ट पूरा हुआ!" else "Test complete!"; textSize=26f; gravity=Gravity.CENTER; setPadding(0,60,0,20) }
                val sc = TextView(this).apply { text = "${s("your_score")}: $gkQuizScore / ${gkQuizList.size*10}"; textSize=20f; gravity=Gravity.CENTER; setPadding(0,10,0,30) }
                val again = Button(this).apply { text = s("play_again"); setOnClickListener { startGkTopicQuiz(gkQuizTopic) } }
                content.addView(t, LinearLayout.LayoutParams(-1,-2))
                content.addView(sc, LinearLayout.LayoutParams(-1,-2))
                content.addView(again, LinearLayout.LayoutParams(-1,-2))
            }
            return
        }
        val q = gkQuizList[gkQuizIndex]
        renderScreen("home") { content ->
            val progress = TextView(this).apply { text = "${s("question_label")} ${gkQuizIndex+1}/${gkQuizList.size}"; textSize=15f; setPadding(0,5,0,18) }
            val scoreView = TextView(this).apply { text = "${s("score_label")}: $gkQuizScore"; textSize=16f; setPadding(0,0,0,18) }
            val questionText = TextView(this).apply { text = if (lang=="hi") q.qHi else q.qEn; textSize=22f; setTextColor(Color.rgb(25,35,50)); setPadding(0,0,0,24) }
            val optionsBox = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
            val displayed = if (lang=="hi") q.optsHi else q.optsEn
            val correct = if (lang=="hi") q.ansHi else q.ansEn
            val buttons = mutableListOf<Button>()
            var answered = false
            val nextButton = Button(this).apply { text = s("next"); isEnabled=false }
            displayed.forEach { option ->
                val b = Button(this).apply {
                    text = option; textSize = 16f; setPadding(24,24,24,24)
                    setBackgroundColor(COLOR_DEFAULT); setTextColor(Color.BLACK)
                }
                b.setOnClickListener {
                    if (answered) return@setOnClickListener
                    answered = true
                    val isCorrect = option == correct
                    b.setBackgroundColor(if (isCorrect) COLOR_BLUE else COLOR_RED); b.setTextColor(Color.WHITE)
                    if (!isCorrect) buttons.firstOrNull { it.text == correct }?.apply { setBackgroundColor(COLOR_BLUE); setTextColor(Color.WHITE) }
                    buttons.forEach { it.isEnabled = false }
                    if (isCorrect) gkQuizScore += 10
                    scoreView.text = "${s("score_label")}: $gkQuizScore"
                    nextButton.isEnabled = true
                }
                buttons.add(b)
                optionsBox.addView(b, LinearLayout.LayoutParams(-1,-2).apply{ setMargins(0,0,0,14) })
            }
            nextButton.setOnClickListener { gkQuizIndex++; showNextGkQuiz() }
            content.addView(progress); content.addView(scoreView); content.addView(questionText)
            content.addView(optionsBox); content.addView(nextButton)
        }
    }

    private fun startCategory(cat: String?) {
        isExam = false
        currentCatFilter = cat
        currentCatKey = cat ?: "ALL"
        prefs().edit().putString("lastCatKey", currentCatKey).apply()
        showNextContinuous()
    }

    private fun showNextContinuous() {
        val factId = nextFact(currentCatKey, currentCatFilter)
        val q = pickRowForFact(factId, currentCatFilter)
        val tab = when (currentCatFilter) { "History" -> "history"; "Science" -> "science"; else -> "home" }
        renderQuestion(
            tab = tab,
            q = q,
            progressLabel = "${s("question_label")} ${getAnswered(currentCatKey)+1}   •   ${qCategory(q)}",
            scoreLabelProvider = { "${s("score_label")}: ${getScore(currentCatKey)}" },
            onAnswered = { correct ->
                if (correct) setScore(currentCatKey, getScore(currentCatKey)+10)
                setAnswered(currentCatKey, getAnswered(currentCatKey)+1)
            },
            onNext = { showNextContinuous() }
        )
    }

    private fun startExam() {
        isExam = true
        examFacts = allFactsFor(null).shuffled()
        examIndex = 0
        examScore = 0
        showNextExam()
    }

    private fun showNextExam() {
        if (examIndex >= examFacts.size) { showExamResult(); return }
        val q = pickRowForFact(examFacts[examIndex], null)
        renderQuestion(
            tab = "exam",
            q = q,
            progressLabel = "${s("question_label")} ${examIndex+1}/${examFacts.size}   •   ${qCategory(q)}",
            scoreLabelProvider = { "${s("score_label")}: $examScore" },
            onAnswered = { correct -> if (correct) examScore += 10 },
            onNext = { examIndex++; showNextExam() }
        )
    }

    private fun showExamResult() {
        renderScreen("exam") { content ->
            val t = TextView(this).apply { text=s("exam_complete"); textSize=28f; gravity=Gravity.CENTER; setPadding(0,60,0,20) }
            val sc = TextView(this).apply { text="${s("your_score")}: $examScore / ${examFacts.size*10}"; textSize=20f; gravity=Gravity.CENTER; setPadding(0,10,0,30) }
            val again = Button(this).apply { text=s("play_again"); setOnClickListener { startExam() } }
            content.addView(t, LinearLayout.LayoutParams(-1,-2))
            content.addView(sc, LinearLayout.LayoutParams(-1,-2))
            content.addView(again, LinearLayout.LayoutParams(-1,-2))
        }
    }

    private fun renderQuestion(
        tab: String,
        q: Question,
        progressLabel: String,
        scoreLabelProvider: () -> String,
        onAnswered: (Boolean) -> Unit,
        onNext: () -> Unit
    ) {
        renderScreen(tab) { content ->
            val progress = TextView(this).apply { text=progressLabel; textSize=15f; setPadding(0,5,0,18) }
            val scoreView = TextView(this).apply { text=scoreLabelProvider(); textSize=16f; setPadding(0,0,0,18) }
            val questionText = TextView(this).apply { text=qText(q); textSize=23f; setTextColor(Color.rgb(25,35,50)); setPadding(0,0,0,24) }
            val optionsBox = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }

            val displayedOptions = qOptions(q)
            val correctDisplay = correctDisplayed(q)
            val buttons = mutableListOf<Button>()
            var answered = false

            val nextButton = Button(this).apply { text=s("next"); isEnabled=false; setOnClickListener { onNext() } }

            displayedOptions.forEach { option ->
                val b = Button(this).apply {
                    text = option; textSize = 16f; setPadding(24,24,24,24)
                    setBackgroundColor(COLOR_DEFAULT); setTextColor(Color.BLACK)
                }
                b.setOnClickListener {
                    if (answered) return@setOnClickListener
                    answered = true
                    val correct = option == correctDisplay
                    b.setBackgroundColor(if (correct) COLOR_BLUE else COLOR_RED)
                    b.setTextColor(Color.WHITE)
                    if (!correct) {
                        buttons.firstOrNull { it.text == correctDisplay }?.apply {
                            setBackgroundColor(COLOR_BLUE); setTextColor(Color.WHITE)
                        }
                    }
                    buttons.forEach { it.isEnabled = false }
                    onAnswered(correct)
                    scoreView.text = scoreLabelProvider()
                    nextButton.isEnabled = true
                }
                buttons.add(b)
                optionsBox.addView(b, LinearLayout.LayoutParams(-1,-2).apply{ setMargins(0,0,0,14) })
            }

            content.addView(progress); content.addView(scoreView)
            content.addView(questionText); content.addView(optionsBox); content.addView(nextButton)
        }
    }
}
