package com.gyandhara.app

import android.app.Activity
import android.content.SharedPreferences
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONArray

data class Question(
    val factId: Int,
    val question: String,
    val options: List<String>,
    val answer: String,
    val category: String,
    val questionHi: String? = null,
    val optionsHi: List<String>? = null,
    val answerHi: String? = null,
    val categoryHi: String? = null
)

object Strings {
    val en = mapOf(
        "app_title" to "Gyan Dhara",
        "tagline" to "Learn anything. Test yourself.",
        "next" to "NEXT",
        "play_again" to "PLAY AGAIN",
        "exam_complete" to "Exam complete!",
        "score_label" to "Score",
        "your_score" to "Your score",
        "question_label" to "Question",
        "correct_answer_prefix" to "Correct answer:",
        "lang_toggle" to "हिंदी",
        "home" to "🏠 Home",
        "cat_history" to "History",
        "cat_science" to "Science",
        "cat_general" to "General Knowledge",
        "cat_exam" to "Practice Exam"
    )
    val hi = mapOf(
        "app_title" to "ज्ञान धारा",
        "tagline" to "कुछ भी सीखें। खुद को परखें।",
        "next" to "अगला",
        "play_again" to "फिर से खेलें",
        "exam_complete" to "परीक्षा पूरी हुई!",
        "score_label" to "स्कोर",
        "your_score" to "आपका स्कोर",
        "question_label" to "प्रश्न",
        "correct_answer_prefix" to "सही उत्तर:",
        "lang_toggle" to "English",
        "home" to "🏠 होम",
        "cat_history" to "इतिहास",
        "cat_science" to "विज्ञान",
        "cat_general" to "सामान्य ज्ञान",
        "cat_exam" to "अभ्यास परीक्षा"
    )
}

class MainActivity : Activity() {
    private lateinit var bank: List<Question>
    private var lang = "en"

    // Continuous-mode state
    private var currentCatKey = "ALL"
    private var currentCatFilter: String? = null
    private var currentQuestion: Question? = null

    // Exam-mode state
    private var isExam = false
    private var examFacts: List<Int> = emptyList()
    private var examIndex = 0
    private var examScore = 0

    private val COLOR_BLUE = Color.rgb(30, 64, 175)
    private val COLOR_RED = Color.rgb(220, 38, 38)
    private val COLOR_DEFAULT = Color.rgb(238, 238, 240)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bank = loadQuestions()
        val savedKey = prefs().getString("lastCatKey", null)
        if (savedKey != null && getAnswered(savedKey) > 0) {
            currentCatKey = savedKey
            currentCatFilter = if (savedKey == "ALL") null else savedKey
            isExam = false
            showNextContinuous()
        } else {
            showHome()
        }
    }

    private fun prefs(): SharedPreferences = getSharedPreferences("gyan_dhara_prefs", MODE_PRIVATE)

    private fun s(key: String): String {
        val map = if (lang == "hi") Strings.hi else Strings.en
        return map[key] ?: (Strings.en[key] ?: key)
    }

    private fun loadQuestions(): List<Question> {
        val text = assets.open("questions.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val opts = listOf("optionA","optionB","optionC","optionD").map { o.getString(it) }
            val optsHi = if (o.has("optionAHi")) {
                listOf("optionAHi","optionBHi","optionCHi","optionDHi").map { o.optString(it, "") }
            } else null
            Question(
                factId = o.getInt("factId"),
                question = o.getString("question"),
                options = opts,
                answer = o.getString("correctAnswer"),
                category = o.optString("category","General"),
                questionHi = o.optString("questionHi", "").ifBlank { null },
                optionsHi = optsHi,
                answerHi = o.optString("correctAnswerHi", "").ifBlank { null },
                categoryHi = o.optString("categoryHi", "").ifBlank { null }
            )
        }
    }

    private fun qText(q: Question): String = if (lang=="hi" && !q.questionHi.isNullOrBlank()) q.questionHi else q.question
    private fun qOptions(q: Question): List<String> = if (lang=="hi" && q.optionsHi!=null && q.optionsHi.all{it.isNotBlank()}) q.optionsHi else q.options
    private fun qCategory(q: Question): String = if (lang=="hi" && !q.categoryHi.isNullOrBlank()) q.categoryHi else q.category
    private fun correctDisplayed(q: Question): String = if (lang=="hi" && !q.answerHi.isNullOrBlank()) q.answerHi else q.answer

    private fun allFactsFor(cat: String?): List<Int> =
        bank.filter { cat == null || it.category == cat }.map { it.factId }.distinct()

    private fun pickRowForFact(factId: Int, cat: String?): Question {
        val matches = bank.filter { it.factId == factId && (cat == null || it.category == cat) }
        return matches.random()
    }

    // ---- Persistent "no repeat until exhausted" queue per category ----
    private fun loadRemaining(catKey: String): MutableList<Int> {
        val s = prefs().getString("remaining_$catKey", null)
        return if (s.isNullOrBlank()) mutableListOf() else s.split(",").filter{it.isNotBlank()}.map{it.toInt()}.toMutableList()
    }
    private fun saveRemaining(catKey: String, list: List<Int>) {
        prefs().edit().putString("remaining_$catKey", list.joinToString(",")).apply()
    }
    private fun nextFact(catKey: String, cat: String?): Int {
        var remaining = loadRemaining(catKey)
        if (remaining.isEmpty()) {
            var fresh = allFactsFor(cat).shuffled()
            val last = prefs().getInt("lastFact_$catKey", -1)
            if (fresh.size > 1 && fresh.first() == last) {
                fresh = fresh.toMutableList().apply { val t=this[0]; this[0]=this[1]; this[1]=t }
            }
            remaining = fresh.toMutableList()
        }
        val fact = remaining.removeAt(0)
        saveRemaining(catKey, remaining)
        prefs().edit().putInt("lastFact_$catKey", fact).apply()
        return fact
    }
    private fun getScore(catKey: String) = prefs().getInt("score_$catKey", 0)
    private fun setScore(catKey: String, v: Int) { prefs().edit().putInt("score_$catKey", v).apply() }
    private fun getAnswered(catKey: String) = prefs().getInt("answered_$catKey", 0)
    private fun setAnswered(catKey: String, v: Int) { prefs().edit().putInt("answered_$catKey", v).apply() }

    private fun base(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
            setBackgroundColor(Color.WHITE)
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(28 + bars.left, 28 + bars.top, 28 + bars.right, 24 + bars.bottom)
            insets
        }
        return root
    }

    private fun showHome() {
        val root = base()
        val langToggle = Button(this).apply {
            text = s("lang_toggle"); textSize = 14f; setPadding(20,10,20,10)
            setOnClickListener { lang = if (lang=="hi") "en" else "hi"; showHome() }
        }
        val toggleRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.END }
        toggleRow.addView(langToggle, LinearLayout.LayoutParams(-2,-2))

        val title = TextView(this).apply { text=s("app_title"); textSize=34f; setTextColor(Color.rgb(20,55,100)); gravity=Gravity.CENTER; setPadding(0,30,0,10) }
        val sub = TextView(this).apply { text=s("tagline"); textSize=18f; gravity=Gravity.CENTER; setPadding(0,0,0,40) }

        fun catButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
            text = label; textSize = 18f; setPadding(0,26,0,26); setOnClickListener { onClick() }
        }

        val historyBtn = catButton(s("cat_history")) { startCategory("History") }
        val scienceBtn = catButton(s("cat_science")) { startCategory("Science") }
        val generalBtn = catButton(s("cat_general")) { startCategory(null) }
        val examBtn = catButton(s("cat_exam")) { startExam() }

        root.addView(toggleRow, LinearLayout.LayoutParams(-1,-2))
        root.addView(title, LinearLayout.LayoutParams(-1,-2))
        root.addView(sub, LinearLayout.LayoutParams(-1,-2))
        for (b in listOf(historyBtn, scienceBtn, generalBtn, examBtn)) {
            root.addView(b, LinearLayout.LayoutParams(-1,-2).apply{ setMargins(0,0,0,16) })
        }
        setContentView(root)
    }

    // ---- Continuous (non-exam) categories ----
    private fun startCategory(cat: String?) {
        isExam = false
        currentCatFilter = cat
        currentCatKey = cat ?: "ALL"
        prefs().edit().putString("lastCatKey", currentCatKey).apply()
        showNextContinuous()
    }

    private fun showNextContinuous() {
        val factId = nextFact(currentCatKey, currentCatFilter)
        val q = pickRowForFact(factId, currentCatFilter)
        currentQuestion = q
        renderQuestion(
            q = q,
            progressLabel = "${s("question_label")} ${getAnswered(currentCatKey)+1}   •   ${qCategory(q)}",
            scoreLabelProvider = { "${s("score_label")}: ${getScore(currentCatKey)}" },
            onAnswered = { correct ->
                if (correct) setScore(currentCatKey, getScore(currentCatKey)+10)
                setAnswered(currentCatKey, getAnswered(currentCatKey)+1)
            },
            onNext = { showNextContinuous() }
        )
    }

    // ---- Practice Exam (fixed length, all unique facts, no repeats by construction) ----
    private fun startExam() {
        isExam = true
        examFacts = allFactsFor(null).shuffled()
        examIndex = 0
        examScore = 0
        showNextExam()
    }

    private fun showNextExam() {
        if (examIndex >= examFacts.size) { showExamResult(); return }
        val q = pickRowForFact(examFacts[examIndex], null)
        currentQuestion = q
        renderQuestion(
            q = q,
            progressLabel = "${s("question_label")} ${examIndex+1}/${examFacts.size}   •   ${qCategory(q)}",
            scoreLabelProvider = { "${s("score_label")}: $examScore" },
            onAnswered = { correct -> if (correct) examScore += 10 },
            onNext = { examIndex++; showNextExam() }
        )
    }

    private fun showExamResult() {
        val root = base()
        val t = TextView(this).apply { text=s("exam_complete"); textSize=30f; gravity=Gravity.CENTER; setPadding(0,70,0,20) }
        val sc = TextView(this).apply { text="${s("your_score")}: $examScore / ${examFacts.size*10}"; textSize=22f; gravity=Gravity.CENTER; setPadding(0,10,0,30) }
        val again = Button(this).apply { text=s("play_again"); setOnClickListener { startExam() } }
        val home = Button(this).apply { text=s("home"); setOnClickListener { showHome() } }
        root.addView(t, LinearLayout.LayoutParams(-1,-2))
        root.addView(sc, LinearLayout.LayoutParams(-1,-2))
        root.addView(again, LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,14)})
        root.addView(home, LinearLayout.LayoutParams(-1,-2))
        setContentView(root)
    }

    // ---- Shared question rendering with color feedback ----
    private fun renderQuestion(
        q: Question,
        progressLabel: String,
        scoreLabelProvider: () -> String,
        onAnswered: (Boolean) -> Unit,
        onNext: () -> Unit
    ) {
        val root = base()
        val homeBtn = TextView(this).apply {
            text = s("home"); textSize = 14f; setPadding(0,0,0,10)
            setOnClickListener { showHome() }
        }
        val progress = TextView(this).apply { text=progressLabel; textSize=15f; setPadding(0,5,0,18) }
        val scoreView = TextView(this).apply { text=scoreLabelProvider(); textSize=16f; setPadding(0,0,0,18) }
        val questionText = TextView(this).apply { text=qText(q); textSize=23f; setTextColor(Color.rgb(25,35,50)); setPadding(0,0,0,24) }
        val optionsBox = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }

        val displayedOptions = qOptions(q)
        val correctDisplay = correctDisplayed(q)
        val buttons = mutableListOf<Button>()
        var answered = false

        val nextButton = Button(this).apply { text=s("next"); isEnabled=false; setOnClickListener { onNext() } }

        displayedOptions.forEach { option ->
            val b = Button(this).apply {
                text = option; textSize = 16f; setPadding(24,24,24,24)
                setBackgroundColor(COLOR_DEFAULT); setTextColor(Color.BLACK)
            }
            b.setOnClickListener {
                if (answered) return@setOnClickListener
                answered = true
                val correct = option == correctDisplay
                b.setBackgroundColor(if (correct) COLOR_BLUE else COLOR_RED)
                b.setTextColor(Color.WHITE)
                if (!correct) {
                    buttons.firstOrNull { it.text == correctDisplay }?.apply {
                        setBackgroundColor(COLOR_BLUE); setTextColor(Color.WHITE)
                    }
                }
                buttons.forEach { it.isEnabled = false }
                onAnswered(correct)
                scoreView.text = scoreLabelProvider()
                nextButton.isEnabled = true
            }
            buttons.add(b)
            optionsBox.addView(b, LinearLayout.LayoutParams(-1,-2).apply{ setMargins(0,0,0,14) })
        }

        root.addView(homeBtn); root.addView(progress); root.addView(scoreView)
        root.addView(questionText); root.addView(optionsBox, LinearLayout.LayoutParams(-1,0,1f)); root.addView(nextButton)
        setContentView(root)
    }
}
