# Build without Android Studio

1. Create a free GitHub repository and upload this whole project.
2. In GitHub: Settings → Secrets and variables → Actions → New repository secret.
3. Add:
   - `KEYSTORE_PASSWORD` = a strong password you choose
   - `KEY_PASSWORD` = a strong password you choose
4. Open Actions → `Build Gyan Dhara AAB` → Run workflow.
5. When it finishes, open the workflow run → Artifacts → `gyan-dhara-release`.
6. Download the ZIP. It contains:
   - `app-release.aab` — upload this to Google Play Console
   - `upload-keystore.jks` — KEEP THIS SAFE for future updates.

Never commit the keystore or passwords to the repository.

The app currently bundles the 10,000-question launch bank locally, so Firebase is not required for this first question-only release.
